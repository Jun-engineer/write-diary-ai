"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// handlers/diaries/scan.ts
var scan_exports = {};
__export(scan_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(scan_exports);
var import_client_bedrock_runtime = require("@aws-sdk/client-bedrock-runtime");

// shared/response.ts
var corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
};
function success(body) {
  return {
    statusCode: 200,
    headers: corsHeaders,
    body: JSON.stringify(body)
  };
}
function badRequest(message) {
  return {
    statusCode: 400,
    headers: corsHeaders,
    body: JSON.stringify({ error: message })
  };
}
function serverError(message = "Internal server error") {
  return {
    statusCode: 500,
    headers: corsHeaders,
    body: JSON.stringify({ error: message })
  };
}

// handlers/diaries/scan.ts
var bedrockClient = new import_client_bedrock_runtime.BedrockRuntimeClient({ region: "us-east-1" });
var handler = async (event) => {
  try {
    if (!event.body) {
      return badRequest("Request body is required");
    }
    const request = JSON.parse(event.body);
    if (!request.imageBase64) {
      return badRequest("imageBase64 is required");
    }
    let imageData = request.imageBase64;
    if (imageData.includes(",")) {
      imageData = imageData.split(",")[1];
    }
    const mediaType = request.mediaType || detectMediaType(imageData);
    const extractedText = await recognizeHandwriting(imageData, mediaType);
    return success({
      text: extractedText,
      success: true
    });
  } catch (error) {
    console.error("Scan error:", error);
    return serverError("Failed to process image");
  }
};
function detectMediaType(base64Data) {
  if (base64Data.startsWith("/9j/")) {
    return "image/jpeg";
  } else if (base64Data.startsWith("iVBORw")) {
    return "image/png";
  } else if (base64Data.startsWith("R0lGOD")) {
    return "image/gif";
  } else if (base64Data.startsWith("UklGR")) {
    return "image/webp";
  }
  return "image/jpeg";
}
async function recognizeHandwriting(imageBase64, mediaType) {
  const prompt = `You are an expert at reading handwritten text. Please carefully read and transcribe all the handwritten text in this image.

Instructions:
- Transcribe the text exactly as written, preserving line breaks and paragraphs
- If you're unsure about a word, make your best guess based on context
- Do not add any commentary, explanations, or corrections
- If there are spelling or grammar mistakes in the handwriting, keep them as-is
- If no text is visible or readable, respond with: [No readable text found]
- Only output the transcribed text, nothing else

Transcribe the handwritten text:`;
  const requestBody = {
    schemaVersion: "messages-v1",
    messages: [
      {
        role: "user",
        content: [
          {
            image: {
              format: mediaType.split("/")[1] || "jpeg",
              source: {
                bytes: imageBase64
              }
            }
          },
          {
            text: prompt
          }
        ]
      }
    ],
    inferenceConfig: {
      maxTokens: 4096
    }
  };
  const command = new import_client_bedrock_runtime.InvokeModelCommand({
    modelId: "amazon.nova-lite-v1:0",
    contentType: "application/json",
    accept: "application/json",
    body: JSON.stringify(requestBody)
  });
  const response = await bedrockClient.send(command);
  const responseBody = JSON.parse(new TextDecoder().decode(response.body));
  if (responseBody.output?.message?.content && responseBody.output.message.content.length > 0) {
    const text = responseBody.output.message.content[0].text.trim();
    if (text === "[No readable text found]") {
      return "";
    }
    return text;
  }
  return "";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
